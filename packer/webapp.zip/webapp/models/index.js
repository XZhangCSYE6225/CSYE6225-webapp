import sequelize from "../config/index.js";
import Product from "./product.js";
import User from "./user.js";

export default sequelize;